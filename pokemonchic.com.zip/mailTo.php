<?php
session_start();
include('error.php');
require_once ("include/function/config.php");
require_once ("include/function/db3.php");
require_once ("include/class/index.class.php");
$db = db($config);
require_once('include/function/globfanction.php');
delete('eventusers','time<='.(int)time());
if(!empty($_GET['code']) && !empty($_GET['user'])){
 $code =  obr_txt($_GET['code']);
 $user = obr_chis($_GET['user']);
 $x = first('SELECT id,items,users FROM eventusers WHERE code="%s" AND users=%d',$code,$user);
 if(!empty($x['id'])){
    plus_item(1,$x['items'],$x['users']);
    delete('eventusers','code="'.mysql_escape_string($code).'" AND users='.(int)$user);
  die("<script>alert('Р СџР С•Р Т‘Р В°РЎР‚Р С•Р С” РЎС“РЎРѓР С—Р ВµРЎв‚¬Р Р…Р С• Р С—Р С•Р В»РЎС“РЎвЂЎР ВµР Р…! Р С›Р Р… Р В¶Р Т‘Р ВµРЎвЂљ Р вЂ™Р В°РЎРѓ Р Р† Р С‘Р Р…Р Р†Р ВµР Р…РЎвЂљР В°РЎР‚Р Вµ!'); window.close();</script>"); 
 }else{
    die('Error');
 }
}else{
  $a = time()+(60*60*24*7);
  die('Error: '.$a.' ');
}
//$s = 'http://league-of-pokemons.ru/mailTo.php?code='.$cod.'&user='.$u;
/*mail("000_06@list.ru","League-Of-Pokemons, Р СџР С•РЎвЂЎРЎвЂљР С•Р Р†РЎвЂ№Р Вµ Р С—Р С•Р Т‘Р В°РЎР‚Р С”Р С‘!", "
        Р вЂ”Р Т‘РЎР‚Р В°РЎРѓРЎвЂљР Р†РЎС“Р в„–РЎвЂљР Вµ, ".$login."
        ---------------------------------
          Р РЋ РЎС“Р Р†Р В°Р В¶Р ВµР Р…Р С‘Р ВµР С, Tacos
          Р С’Р Т‘Р СР С‘Р Р…Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂљР С•РЎР‚ League-Of-Pokemons.ru
          000_01@list.ru
      ", "From:000_06@list.ru");       */
      
      /* Р С—Р С•Р В»РЎС“РЎвЂЎР В°РЎвЂљР ВµР В»Р С‘ */
 /**
$users = select('SELECT login,email,id FROM users'); // Р Р†Р С•Р В·Р Р†РЎР‚Р В°РЎвЂ°Р В°Р ВµРЎвЂљ Р Р†РЎРѓР Вµ
function ssilka($user){
  $a = rand(111111, 999999).date('His'); 
  $cod = md5($a);
  $time  = time()+(60*60*24*1);
  insert('eventusers',array('users'=>$user, 'code'=>$cod, 'items'=>5, 'time'=>$time));
  return  $cod;
}
$subject = "League-Of-Pokemons, Р СџР С•РЎвЂЎРЎвЂљР С•Р Р†РЎвЂ№Р Вµ Р С—Р С•Р Т‘Р В°РЎР‚Р С”Р С‘!";
foreach($users  as $usersrow){ 
  $to   = $usersrow['login']." <".$usersrow['email'].">";
  $ssil = ssilka($usersrow['id']);
  $sx   = 'http://League-Of-Pokemons.ru/mailTo.php?code='.$ssil.'&user='.$usersrow['id'];  
$message = '
<html>
<head>
 <title>Р СџР С•РЎвЂЎРЎвЂљР С•Р Р†РЎвЂ№Р Вµ Р С—Р С•Р Т‘Р В°РЎР‚Р С”Р С‘ Р Т‘Р В»РЎРЏ Р Р†РЎРѓР ВµРЎвЂ¦!</title>
</head>
<body>
<p>Р вЂ”Р Т‘РЎР‚Р В°Р Р†РЎРѓРЎвЂљР Р†РЎС“Р в„–РЎвЂљР Вµ, '. $usersrow['login'].'!<br>
  Р вЂ™РЎвЂ№ (Р С‘Р В»Р С‘ Р С”РЎвЂљР С•-РЎвЂљР С• Р Т‘РЎР‚РЎС“Р С–Р С•Р в„–) Р В·Р В°РЎР‚Р ВµР С–Р С‘РЎРѓРЎвЂљРЎР‚Р С‘РЎР‚Р С•Р Р†Р В°Р В»РЎРѓРЎРЏ Р Р…Р В° Р С—РЎР‚Р С•Р ВµР С”РЎвЂљР Вµ: League-Of-Pokemons Р С—Р С•Р Т‘ РЎРЊРЎвЂљР С‘Р С E-mail Р В°Р Т‘РЎР‚Р ВµРЎРѓР С•Р С Р С‘ Р С—Р С•Р Т‘Р С—Р С‘РЎРѓР В°Р В»РЎРѓРЎРЏ Р С—Р С•Р В»РЎС“РЎвЂЎР В°РЎвЂљРЎРЉ Р Р†Р В°Р В¶Р Р…РЎвЂ№Р Вµ Р Р…Р С•Р Р†Р С•РЎРѓРЎвЂљР С‘!</p>
<table>
 <tr>
  <td>
    Р РЋР ВµР С–Р С•Р Т‘Р Р…РЎРЏ, Р Р† Р С—РЎР‚Р С•Р ВµР С”РЎвЂљР Вµ: http://League-Of-Pokemons.ru Р Р†РЎРѓР ВµР С Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»РЎРЏР С Р В±РЎвЂ№Р В»Р С‘ Р С—Р С•РЎРѓР В»Р В°Р Р…РЎвЂ№ Р С—Р С•Р Т‘Р В°РЎР‚Р С”Р С‘! Р В§РЎвЂљР С•Р В±РЎвЂ№ Р С‘РЎвЂ¦ Р С—Р С•Р В»РЎС“РЎвЂЎР С‘РЎвЂљРЎРЉ, Р вЂ™Р В°Р С Р Р…РЎС“Р В¶Р Р…Р С• Р С—Р ВµРЎР‚Р ВµР в„–РЎвЂљР С‘ Р С—Р С• РЎРЊРЎвЂљР С•Р в„– РЎРѓРЎРѓРЎвЂ№Р В»Р С”Р Вµ: '.$sx.'. Р вЂ™Р Р…Р С‘Р СР В°Р Р…Р С‘Р Вµ! Р РЋРЎРѓРЎвЂ№Р В»Р С”Р В° Р Т‘Р ВµР в„–РЎРѓРЎвЂљР Р†РЎС“Р ВµРЎвЂљ 24 РЎвЂЎР В°РЎРѓР В° Р С—Р С•Р В»РЎРѓР Вµ Р С—Р С•Р В»РЎС“РЎвЂЎР ВµР Р…Р С‘РЎРЏ. Р вЂќР В»РЎРЏ Р С•РЎвЂљР С”Р В°Р В·Р В° Р С—Р С•Р Т‘Р В°РЎР‚Р С”Р В° Р Т‘Р С•РЎРѓРЎвЂљР В°РЎвЂљР С•РЎвЂЎР Р…Р С• Р Р†РЎРѓР ВµР С–Р С• Р В»Р С‘РЎв‚¬РЎРЉ Р С—РЎР‚Р С•Р С‘Р С–Р Р…Р С•РЎР‚Р С‘РЎР‚Р С•Р Р†Р В°РЎвЂљРЎРЉ РЎРЊРЎвЂљР С• РЎРѓР С•Р С•Р В±РЎвЂ°Р ВµР Р…Р С‘Р Вµ!
  </td>
 </tr>
 <tr>
  <td>Р РЋР С—Р В°РЎРѓР С‘Р В±Р С• Р В·Р В° РЎвЂљР С•, РЎвЂЎРЎвЂљР С• Р вЂ™РЎвЂ№ Р С‘Р С–РЎР‚Р В°Р ВµРЎвЂљР Вµ РЎРѓ Р Р…Р В°Р СР С‘! Р РЋ РЎС“Р Р†Р В°Р В¶Р ВµР Р…Р С‘Р ВµР С, Р С”Р С•Р СР В°Р Р…Р Т‘Р В° League-Of-Pokemons.ru</td>
 </tr>
</table>
</body>
</html>
';
/* Р вЂќР В»РЎРЏ Р С•РЎвЂљР С—РЎР‚Р В°Р Р†Р С”Р С‘ HTML-Р С—Р С•РЎвЂЎРЎвЂљРЎвЂ№ Р Р†РЎвЂ№ Р СР С•Р В¶Р ВµРЎвЂљР Вµ РЎС“РЎРѓРЎвЂљР В°Р Р…Р С•Р Р†Р С‘РЎвЂљРЎРЉ РЎв‚¬Р В°Р С—Р С”РЎС“ Content-type. 
$headers= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; Charset=Windows-1251\r\n";

$headers .= "From: League-Of-Pokemons Events Day <events@League-Of-Pokemons.ru>\r\n";
$headers .= "Cc: events@League-Of-Pokemons.ru/\r\n";
$headers .= "Bcc: events@League-Of-Pokemons.ru/\r\n";
mail($to, $subject, $message, $headers);
}                 */

?>