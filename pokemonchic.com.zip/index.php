<?php
declare(strict_types=1);

require_once __DIR__ . '/include/function/config.php';
require_once __DIR__ . '/include/function/db3.php';
require_once __DIR__ . '/include/function/globfanction.php';
require_once __DIR__ . '/include/function/functionusers.php';
require_once __DIR__ . '/include/class/index.class.php';
require_once __DIR__ . '/ban.php';

app_start_session();

if (($_GET['go'] ?? '') === 'exits') {
    app_destroy_session();
    app_redirect('/');
}

$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
if ($requestPath === '/index.php') {
    app_redirect('/', 301);
}

$ranking = new RankingsIndex();
$rang = $ranking->getTopRang();
$maney = $ranking->getTopMoney();
$dexNorm = $ranking->getTopDex();
$dexShiny = $ranking->getTopShinyDex();

$myrow = false;
if (!empty($_SESSION['login']) && !empty($_SESSION['password']) && !empty($_SESSION['browse'])) {
    if ($_SESSION['browse'] === getBrowserSign()) {
        $myrow = first(
            'SELECT id,login,activation,password,groups FROM users WHERE login="%s" AND password="%s" AND activation=1',
            (string) $_SESSION['login'],
            (string) $_SESSION['password']
        );
        $_SESSION['browse'] = getBrowserSign();
    }
}

$news = [
    [
        'date' => '12 Р С’Р Р†Р С–, 2014',
        'title' => 'Р РЋР В±Р ВµР В¶Р В°Р Р†РЎв‚¬Р С‘Р Вµ Р С—Р С•Р С”Р ВµР СР С•Р Р…РЎвЂ№',
        'text' => 'Р вЂ™Р С• Р Р†РЎР‚Р ВµР СРЎРЏ Р С•РЎвЂљР С”РЎР‚РЎвЂ№РЎвЂљР С‘РЎРЏ Р С‘Р С–РЎР‚РЎвЂ№ РЎРѓР В±Р ВµР В¶Р В°Р В»Р С‘ Р С—Р С•Р С”Р ВµР СР С•Р Р…РЎвЂ№ Р С—Р С•РЎРѓР В»Р Вµ Р Р…Р В°Р С—Р В°Р Т‘Р ВµР Р…Р С‘РЎРЏ Р С”Р С•Р СР В°Р Р…Р Т‘РЎвЂ№ "Р В Р В°Р С”Р ВµРЎвЂљР В°" Р Р…Р В° Р В»Р В°Р В±Р С•РЎР‚Р В°РЎвЂљР С•РЎР‚Р С‘РЎР‹ Р С—РЎР‚Р С•РЎвЂћР ВµРЎРѓРЎРѓР С•РЎР‚Р В° Р С›РЎС“Р С”Р В°. Р СћРЎР‚Р ВµР Р…Р ВµРЎР‚РЎвЂ№ Р СР С•Р С–РЎС“РЎвЂљ Р С—Р С•Р в„–Р СР В°РЎвЂљРЎРЉ РЎРѓР В±Р ВµР В¶Р В°Р Р†РЎв‚¬Р С‘РЎвЂ¦ Р С—Р С•Р С”Р ВµР СР С•Р Р…Р С•Р Р† Р Р† Р С’Р В»Р В°Р В±Р В°РЎРѓРЎвЂљР С‘Р С‘.',
    ],
    [
        'date' => '12 Р С’Р Р†Р С–, 2014',
        'title' => 'Р ВР Р†Р ВµР Р…РЎвЂљ',
        'text' => 'Р Р€Р Р†Р ВµР В»Р С‘РЎвЂЎР ВµР Р… Р С•Р С—РЎвЂ№РЎвЂљ, Р СР С•Р Р…Р ВµРЎвЂљРЎвЂ№, РЎРѓРЎвЂЎР В°РЎРѓРЎвЂљРЎРЉР Вµ Р С‘ РЎРЊР Р…Р ВµРЎР‚Р С–Р С‘РЎРЏ. Р СџРЎР‚Р С‘РЎРЏРЎвЂљР Р…Р С•Р в„– Р С‘Р С–РЎР‚РЎвЂ№.',
    ],
    [
        'date' => '12 Р С’Р Р†Р С–, 2014',
        'title' => 'Р С›РЎвЂљР С”РЎР‚РЎвЂ№РЎвЂљР С‘Р Вµ Р С‘Р С–РЎР‚РЎвЂ№',
        'text' => 'League Of Pokemons - Р СР Р…Р С•Р С–Р С•Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»РЎРЉРЎРѓР С”Р В°РЎРЏ Р В±РЎР‚Р В°РЎС“Р В·Р ВµРЎР‚Р Р…Р В°РЎРЏ Р С•Р Р…Р В»Р В°Р в„–Р Р…-Р С‘Р С–РЎР‚Р В° Р С—Р С• Р СР С•РЎвЂљР С‘Р Р†Р В°Р С Р СР С‘РЎР‚Р В° Pokemon РЎРѓ РЎР‚Р ВµР С–Р С‘Р С•Р Р…Р В°Р СР С‘, Р В±Р С•РЎРЏР СР С‘, Р С—Р С•Р С”Р ВµР Т‘Р ВµР С”РЎРѓР С•Р С Р С‘ РЎР‚Р В°Р В·Р Р†Р С‘РЎвЂљР С‘Р ВµР С Р С”Р С•Р СР В°Р Р…Р Т‘РЎвЂ№.',
    ],
];

function render_rank_list(array $items, string $scoreKey, string $emptyText = 'РІР‚вЂќ'): void
{
    if ($items === []) {
        echo '<div class="muted">' . app_e($emptyText) . '</div>';
        return;
    }

    $position = 1;
    foreach ($items as $item) {
        if (!isset($item['id'], $item[$scoreKey])) {
            continue;
        }

        $user = color_group_users((int) $item['id'], 2);
        $score = number_format((int) $item[$scoreKey], 0, '.', ' ');
        echo '<div><span class="rank-position">' . $position . '.</span> ' . $user . ' <span class="muted">(' . app_e($score) . ')</span></div>';
        $position++;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>League of Pokemons - Р вЂњР В»Р В°Р Р†Р Р…Р В°РЎРЏ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="/">
    <link rel="stylesheet" href="/css/style0.css">
    <link rel="stylesheet" href="/css/skin.css">
    <link rel="stylesheet" media="screen" href="/css/superfish.css">
    <script src="/script/jquery.js"></script>
    <style>
        body {
            min-width: 1200px;
            overflow-x: auto;
        }
        #main .wrapper {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
        }
        #posts-list {
            flex: 3;
            margin-right: 20px;
        }
        #sidebar {
            flex: 1;
            min-width: 300px;
        }
        #nav.sf-menu {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: nowrap;
        }
        #nav.sf-menu > li {
            display: inline-block;
            margin: 0;
            padding: 0;
        }
        #nav.sf-menu > li > a {
            display: inline-block;
            white-space: nowrap;
            line-height: 32px;
        }
        header .wrapper {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        header nav {
            flex: 1 1 auto;
        }
        #logo img {
            display: block;
            height: auto;
        }
        .rank-position {
            color: #cc66ff;
        }
        .muted {
            color: #aaa;
        }
    </style>
</head>
<body>
<div id="bar">
    <div id="autorizeDiv">
        <?php if (!$myrow): ?>
            <form name="formAut" id="formAut" action="/autoriz.php" method="post">
                Р вЂєР С•Р С–Р С‘Р Р…: <input id="login" class="formAut" name="LOGIN" type="text" size="16" maxlength="16" value="" autocomplete="username">
                Р СџР В°РЎР‚Р С•Р В»РЎРЉ: <input id="pass" class="formAut" name="PASSWORD" type="password" size="16" maxlength="40" value="" autocomplete="current-password">
                <input id="autoChec" class="checAut" name="AUTO" type="checkbox"> Р С’Р Р†РЎвЂљР С•Р Р†РЎвЂ¦Р С•Р Т‘
                <input type="submit" class="btInp" value="Р вЂ™РЎвЂ¦Р С•Р Т‘">
                | <button type="button" class="btInp" onclick="location.href='index.php?go=reg';">Р В Р ВµР С–Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂ Р С‘РЎРЏ</button>
                | <button type="button" class="btInp" onclick="location.href='index.php?go=sendpass';">Р вЂ™Р С•РЎРѓРЎРѓРЎвЂљР В°Р Р…Р С•Р Р†Р В»Р ВµР Р…Р С‘Р Вµ Р С—Р В°РЎР‚Р С•Р В»РЎРЏ</button>
            </form>
        <?php else: ?>
            Р СџРЎР‚Р С‘Р Р†Р ВµРЎвЂљРЎРѓРЎвЂљР Р†РЎС“Р ВµР С Р вЂ™Р В°РЎРѓ, РЎвЂљРЎР‚Р ВµР Р…Р ВµРЎР‚: <?= app_e($_SESSION['login']) ?>!
            | <button type="button" class="btInp" onclick="window.open('/game.php?go=map','mir');">Р вЂ™ Р СР С‘РЎР‚</button>
            | <button type="button" class="btInp" onclick="window.open('/game.php?go=start','game');">Р вЂ™ Р С‘Р С–РЎР‚РЎС“</button>
            | <button type="button" class="btInp" onclick="location.href='/?go=exits';">Р вЂ™РЎвЂ№РЎвЂ¦Р С•Р Т‘</button>
        <?php endif; ?>
    </div>
    <div id="autMes" style="display:none;"></div>
    <div id="autherror" style="display:none;"></div>
</div>

<header class="clearfix">
    <div class="wrapper">
        <a href="/" id="logo"><img src="/img/lop.png" alt="League of Pokemons"></a>
        <nav>
            <ul id="nav" class="sf-menu">
                <li class="current-menu-item"><a href="/">Р вЂњР В»Р В°Р Р†Р Р…Р В°РЎРЏ</a></li>
                <li><a href="/rules">Р СџРЎР‚Р В°Р Р†Р С‘Р В»Р В°</a></li>
                <li><a href="/about">Р С› Р Р…Р В°РЎРѓ</a></li>
                <li><a href="index.php?go=reg">Р В Р ВµР С–Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂ Р С‘РЎРЏ</a></li>
                <li><a href="http://forum.league-of-pokemons.ru/" target="_blank" rel="noopener">Р В¤Р С•РЎР‚РЎС“Р С</a></li>
                <li><a href="/vk-group">Р вЂњРЎР‚РЎС“Р С—Р С—Р В° Р вЂ™Р С™</a></li>
            </ul>
        </nav>
        <div id="combo-holder"></div>
    </div>
</header>

<div id="main">
    <div class="wrapper clearfix">
        <div id="posts-list">
            <h2 class="page-heading"><span>News</span></h2>

            <?php foreach ($news as $item): ?>
                <article class="format-standard">
                    <div class="entry-date">
                        <div class="number"><?= app_e(explode(' ', $item['date'])[0]) ?></div>
                        <div class="year"><?= app_e(substr($item['date'], 3)) ?></div>
                    </div>
                    <div class="feature-image"></div>
                    <h2 class="post-heading"><?= app_e($item['title']) ?></h2>
                    <div class="excerpt"><?= app_e($item['text']) ?></div>
                    <div class="meta">
                        <div class="user"><a href="/game.php?go=trenInfo&amp;id=1" style="color:grey;">Tacos</a></div>
                    </div>
                </article>
            <?php endforeach; ?>

            <div class="page-navigation clearfix"></div>
        </div>

        <aside id="sidebar">
            <ul>
                <li class="block">
                    <h4><img src="/img/prize/1nagrada.png" style="vertical-align:middle;" alt=""> <span class="rank-position">Р вЂР С•Р в„–РЎвЂ РЎвЂ№:</span></h4>
                    <b><?php render_rank_list(is_array($rang) ? $rang : [], 'rang_b'); ?></b>
                </li>

                <li class="block">
                    <h4><span class="rank-position">Р СљР С‘Р В»Р В»Р С‘Р С•Р Р…Р ВµРЎР‚РЎвЂ№:</span></h4>
                    <b><?php render_rank_list(is_array($maney) ? $maney : [], 'count'); ?></b>
                </li>

                <li class="block">
                    <h4><span class="rank-position">Top - Pokedex:</span></h4>
                    <b><?php render_rank_list(is_array($dexNorm) ? $dexNorm : [], 'count_poke'); ?></b>
                </li>

                <li class="block">
                    <h4><span class="rank-position">Top - Shiny-dex:</span></h4>
                    <b><?php render_rank_list(is_array($dexShiny) ? $dexShiny : [], 'count_poke_s'); ?></b>
                </li>
            </ul>
            <em id="corner"></em>
        </aside>
    </div>
</div>

<footer>
    <div class="wrapper">
        <ul class="widget-cols clearfix">
            <li>
                <div class="widget-block">
                    <h4>Р С›Р Р…Р В»Р В°Р в„–Р Р… Р С‘Р С–РЎР‚Р С•Р С”Р С•Р Р†:</h4>
                    <div class="recent-post">
                        <h4>Р вЂ™РЎРѓР ВµР С–Р С• Р С‘Р С–РЎР‚Р С•Р С”Р С•Р Р†:</h4>
                        <h4>Р РЋР ВµР С–Р С•Р Т‘Р Р…РЎРЏ Р В·Р В°РЎв‚¬Р В»Р С•:</h4>
                    </div>
                </div>
            </li>
        </ul>

        <div class="footer-bottom">
            <center>League of Pokemons Р’В© 2014</center>
            <center><b>Р вЂ™РЎРѓР Вµ Р С—РЎР‚Р В°Р Р†Р В° Р Р…Р В° Р С—Р С•Р С”Р ВµР СР С•Р Р…Р С•Р Р† Р С—РЎР‚Р С‘Р Р…Р В°Р Т‘Р В»Р ВµР В¶Р В°РЎвЂљ Р С”Р С•Р СР С—Р В°Р Р…Р С‘Р С‘: Р’В«NintendoР’В» Р’В© 1996 - 2014</b></center>
            <div class="right">
                <ul id="social-bar"></ul>
            </div>
        </div>
    </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[onclick*="exits"]').forEach(function(button) {
        button.onclick = function() {
            localStorage.clear();
            sessionStorage.clear();
            location.href = '/?go=exits';
        };
    });
});
</script>
</body>
</html>
