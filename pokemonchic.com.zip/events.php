<?php
// events.php РІР‚вЂќ SSE Р С—Р С•РЎвЂљР С•Р С” РЎРѓР С•Р В±РЎвЂ№РЎвЂљР С‘Р в„– Р Т‘Р В»РЎРЏ РЎвЂљР ВµР С”РЎС“РЎвЂ°Р ВµР С–Р С• РЎР‹Р В·Р ВµРЎР‚Р В°
session_start();
require_once ("include/function/config.php");
require_once ("include/function/db3.php");
require_once ("include/function/globfanction.php");
date_default_timezone_set('Europe/Moscow');

if (empty($_SESSION['login']) || empty($_SESSION['password'])) {
  http_response_code(401);
  exit;
}

// Р вЂ™Р С’Р вЂ“Р СњР С›: Р С•РЎвЂљР С—РЎС“РЎРѓР С”Р В°Р ВµР С Р В±Р В»Р С•Р С”Р С‘РЎР‚Р С•Р Р†Р С”РЎС“ РЎРѓР ВµРЎРѓРЎРѓР С‘Р С‘, РЎвЂЎРЎвЂљР С•Р В±РЎвЂ№ Р С—Р В°РЎР‚Р В°Р В»Р В»Р ВµР В»РЎРЉР Р…Р С• Р С–РЎР‚РЎС“Р В·Р С‘Р В»Р С‘РЎРѓРЎРЉ AJAX-Р В±Р В»Р С•Р С”Р С‘
session_write_close();

$db = db($config);

// Р вЂ”Р В°Р С–Р С•Р В»Р С•Р Р†Р С”Р С‘ SSE
header('Content-Type: text/event-stream; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Connection: keep-alive');
// Р вЂќР В»РЎРЏ Nginx: Р С•РЎвЂљР С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРЉ Р В±РЎС“РЎвЂћР ВµРЎР‚Р С‘Р В·Р В°РЎвЂ Р С‘РЎР‹, Р С‘Р Р…Р В°РЎвЂЎР Вµ РЎРѓР С•Р В±РЎвЂ№РЎвЂљР С‘РЎРЏ РІР‚СљР В·Р В°Р В»Р С‘Р С—Р Р…РЎС“РЎвЂљРІР‚Сњ
header('X-Accel-Buffering: no');

ignore_user_abort(true);
set_time_limit(0);

// Р РЋ Р С”Р В°Р С”Р С•Р в„– РЎвЂљР С•РЎвЂЎР С”Р С‘ РЎРѓР В»Р В°РЎвЂљРЎРЉ РЎРѓР С•Р В±РЎвЂ№РЎвЂљР С‘РЎРЏ
$lastId = 0;
if (isset($_SERVER['HTTP_LAST_EVENT_ID'])) {
  $lastId = (int)$_SERVER['HTTP_LAST_EVENT_ID'];
} elseif (isset($_GET['since'])) {
  $lastId = (int)$_GET['since'];
}

// Р Р€Р В·Р Р…Р В°Р в„– РЎвЂљР ВµР С”РЎС“РЎвЂ°Р ВµР С–Р С• Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»РЎРЏ (Р С”Р В°Р С” Р Р† game.php)
$myrow = first('SELECT * FROM users WHERE login="%s" AND password="%s" AND activation=1', $_SESSION['login'], $_SESSION['password']);
if (!$myrow || empty($myrow['id'])) {
  http_response_code(401);
  exit;
}

$userId = (int)$myrow['id'];

// Р ТђР ВµР В»Р С—Р ВµРЎР‚: Р С•РЎвЂљР С—РЎР‚Р В°Р Р†Р С‘РЎвЂљРЎРЉ Р С•Р Т‘Р Р…Р С• SSE-РЎРѓР С•Р С•Р В±РЎвЂ°Р ВµР Р…Р С‘Р Вµ
function sse_send($event, $id, $data) {
  // id: Р С—Р С•Р В·Р Р†Р С•Р В»РЎРЏР ВµРЎвЂљ РЎР‚Р ВµРЎРѓРЎР‹Р СР С‘РЎвЂљРЎРЉ Р С—Р С•РЎвЂљР С•Р С”
  if ($id) echo "id: {$id}\n";
  if ($event) echo "event: {$event}\n";
  echo 'data: ' . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
  @ob_flush(); @flush();
}

// Р вЂњР В»Р В°Р Р†Р Р…РЎвЂ№Р в„– РЎвЂ Р С‘Р С”Р В» long-run: Р Т‘Р ВµРЎР‚Р В¶Р С‘Р С РЎРѓР С•Р ВµР Т‘Р С‘Р Р…Р ВµР Р…Р С‘Р Вµ ~60 РЎРѓР ВµР С”, Р С—Р С•РЎвЂљР С•Р С Р С”Р В»Р С‘Р ВµР Р…РЎвЂљ Р С—Р ВµРЎР‚Р ВµР С—Р С•Р Т‘Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРѓРЎРЏ
$started = time();
while (!connection_aborted() && (time() - $started) < 60) {
  // TODO: Р В·Р В°Р СР ВµР Р…Р С‘РЎвЂљР Вµ Р Р…Р В° Р Р†Р В°РЎв‚¬РЎС“ РЎР‚Р ВµР В°Р В»РЎРЉР Р…РЎС“РЎР‹ Р Р†РЎвЂ№Р В±Р С•РЎР‚Р С”РЎС“ РЎРѓР С•Р В±РЎвЂ№РЎвЂљР С‘Р в„–
  // Р СџРЎР‚Р С‘Р СР ВµРЎР‚: РЎвЂљР В°Р В±Р В»Р С‘РЎвЂ Р В° events(id, user_id, type, payload_json, created_at)
  $rows = all('SELECT id, type, payload_json 
               FROM events 
               WHERE user_id=%d AND id>%d 
               ORDER BY id ASC LIMIT 50', $userId, $lastId);

  if ($rows) {
    foreach ($rows as $r) {
      $payload = json_decode($r['payload_json'], true) ?: [];
      // Р СџРЎР‚Р С‘Р СР ВµРЎР‚: РЎРѓР С—Р ВµРЎвЂ Р С‘Р В°Р В»РЎРЉР Р…РЎвЂ№Р Вµ Р С‘Р СР ВµР Р…Р В° РЎРѓР С•Р В±РЎвЂ№РЎвЂљР С‘Р в„– Р С—Р С• type
      // challenge РІР‚вЂќ Р С—РЎР‚Р С‘Р С–Р В»Р В°РЎв‚¬Р ВµР Р…Р С‘Р Вµ Р Р† Р В±Р С•Р в„–
      // chat РІР‚вЂќ Р Р…Р С•Р Р†Р С•Р Вµ РЎРѓР С•Р С•Р В±РЎвЂ°Р ВµР Р…Р С‘Р Вµ
      // battle_update РІР‚вЂќ Р С‘Р В·Р СР ВµР Р…Р ВµР Р…Р С‘РЎРЏ Р Р† РЎвЂљР ВµР С”РЎС“РЎвЂ°Р ВµР С Р В±Р С•РЎР‹
      $eventName = $r['type']; 
      $lastId = (int)$r['id'];
      sse_send($eventName, $lastId, $payload);
    }
  }

  // Р С›РЎвЂљР С—РЎР‚Р В°Р Р†Р С‘Р С Р С—Р С‘Р Р…Р С–, РЎвЂЎРЎвЂљР С•Р В±РЎвЂ№ РЎРѓР С•Р ВµР Т‘Р С‘Р Р…Р ВµР Р…Р С‘Р Вµ Р Р…Р Вµ Р В·Р В°РЎРѓРЎвЂ№Р С—Р В°Р В»Р С• Р С—РЎР‚Р С•Р С”РЎРѓР С‘
  sse_send('ping', $lastId, ['t' => time()]);

  usleep(300000); // 300Р СРЎРѓ
}

// Р СџР С• Р С•Р С”Р С•Р Р…РЎвЂЎР В°Р Р…Р С‘Р С‘ РЎвЂ Р С‘Р С”Р В»Р В° Р С—РЎР‚Р С•РЎРѓРЎвЂљР С• Р Р†РЎвЂ№РЎвЂ¦Р С•Р Т‘Р С‘Р С РІР‚вЂќ РЎвЂћРЎР‚Р С•Р Р…РЎвЂљ Р С—Р ВµРЎР‚Р ВµР С—Р С•Р Т‘Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРѓРЎРЏ
