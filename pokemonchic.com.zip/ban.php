<?php
declare(strict_types=1);

require_once __DIR__ . '/include/function/config.php';
require_once __DIR__ . '/include/function/db3.php';

app_start_session();
db($config);

function ban_current_ip(): string
{
    return app_client_ip();
}

$now = time();
$_SESSION['ipBan'] = isset($_SESSION['ipBan']) ? (int) $_SESSION['ipBan'] : 0;

if ($_SESSION['ipBan'] > $now) {
    http_response_code(403);
    echo '<center><b>Р вЂќР С•РЎРѓРЎвЂљРЎС“Р С— Р Р†РЎР‚Р ВµР СР ВµР Р…Р Р…Р С• Р С•Р С–РЎР‚Р В°Р Р…Р С‘РЎвЂЎР ВµР Р….</b></center>';
    exit;
}

$ip = ban_current_ip();
$ipRes = first('SELECT ip FROM banip WHERE ip="%s"', $ip);

if (!empty($ipRes['ip'])) {
    http_response_code(403);
    echo '<center><b>Р вЂ™Р В°РЎв‚¬ IP Р В°Р Т‘РЎР‚Р ВµРЎРѓ Р В±РЎвЂ№Р В» Р В·Р В°Р В±Р В»Р С•Р С”Р С‘РЎР‚Р С•Р Р†Р В°Р Р…. Р вЂ™ Р В±Р В°Р Р… Р С—Р С• IP Р С—Р С•Р С—Р В°Р Т‘Р В°РЎР‹РЎвЂљ РЎвЂљР С•Р В»РЎРЉР С”Р С• РЎвЂљР Вµ Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»Р С‘, Р С”Р С•РЎвЂљР С•РЎР‚РЎвЂ№Р Вµ Р СР Р…Р С•Р С–Р С•Р С”РЎР‚Р В°РЎвЂљР Р…Р С• Р Р…Р В°РЎР‚РЎС“РЎв‚¬Р В°Р В»Р С‘ Р С—РЎР‚Р В°Р Р†Р С‘Р В»Р В° Р СџР С•Р С”Р ВµР В»Р ВµР С–Р ВµР Р…Р Т‘РЎвЂ№.</b></center>';
    exit;
}
