<?php
for ($i=0; $i<15;$i++) {sleep(1); } print 123;
?>